import React from 'react';
import BottomLeft from '../components/BottomLeft';
import BottomRight from '../components/BottomRight';
import TopLeft from '../components/TopLeft';
import TopRight from '../components/TopRight';

const Dashboard: React.FC = () => {
  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      height: '100vh', 
      padding: '1rem', 
      boxSizing: 'border-box' 
    }}>
      <div style={{
        flex: 1,
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gridTemplateRows: '1fr 1fr',
        gap: '1rem'
      }}>
        <TopLeft />
        <TopRight />
        <BottomLeft />
        <BottomRight />
      </div>
      <div style={{ marginTop: '1rem' }}>
        <input 
          type="text" 
          placeholder="User input here..." 
          style={{ width: '100%', padding: '0.5rem', boxSizing: 'border-box' }}
        />
      </div>
    </div>
  );
};

export default Dashboard;
