"use client";

import React, { useEffect, useState } from 'react';

type Data = {
  content: string;
};

const TopLeft: React.FC = () => {
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchChatGPT = async () => {
      try {
        const res = await fetch('/api/chatgpt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: 'Hello, how are you?' })
        });

        if (!res.ok) {
          const errorResponse = await res.json();
          throw new Error(errorResponse.error || 'API error');
        }

        const jsonData = await res.json();
        setData(jsonData);
      } catch (err: any) {
        setError(err.message);
      }
    };

    fetchChatGPT();
  }, []);

  return (
    <div className="text-gray-800">
      {error && <p className="text-red-500">Error: {error}</p>}
      {data ? data.content : 'Loading...'}
    </div>
  );
};

export default TopLeft;
