"use client";
import React, { useEffect, useState } from 'react';

type Data = {
  message: string;
};

const BottomRight: React.FC = () => {
  const [data, setData] = useState<Data | null>(null);

  useEffect(() => {
    // Example GET request logic
    // fetch('/api/bottomright')
    //   .then(response => response.json())
    //   .then(fetchedData => setData(fetchedData));

    // Placeholder data
    setData({ message: 'Bottom Right Data Placeholder' });
  }, []);

  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem' }}>
      {data ? data.message : 'Loading...'}
    </div>
  );
};

export default BottomRight;
