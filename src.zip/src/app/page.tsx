"use client";

import BottomLeft from "./components/BottomLeft";
import BottomRight from "./components/BottomRight";
import TopLeft from "./components/TopLeft";
import TopRight from "./components/TopRight";

export default function Home() {
  return (
    <div className="min-h-screen p-8 sm:p-20 font-[family-name:var(--font-geist-sans)] flex flex-col gap-8 bg-gray-50">
      {/* Responsive Grid with modern styling */}
      <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 sm:grid-rows-2 gap-6 w-full">
        <div className="bg-white rounded-xl shadow-md p-4 hover:shadow-lg transition-shadow">
          <TopLeft />
        </div>
        <div className="bg-white rounded-xl shadow-md p-4 hover:shadow-lg transition-shadow">
          <TopRight />
        </div>
        <div className="bg-white rounded-xl shadow-md p-4 hover:shadow-lg transition-shadow">
          <BottomLeft />
        </div>
        <div className="bg-white rounded-xl shadow-md p-4 hover:shadow-lg transition-shadow">
          <BottomRight />
        </div>
      </div>

      {/* Modern input field */}
      <div className="flex items-center w-full">
        <input
          type="text"
          placeholder="Type something..."
          className="w-full p-3 border border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
        />
      </div>
    </div>
  );
}
